import React, { Component } from 'react';
import { View, Text, TextInput, Button, Image} from 'react-native';
import { styles } from './styles';
 
class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      precoAlcool: 0,
      precoGasolina: 0,
      resultado: ''
    };
    
    this.pegaPrecoAlcool = this.pegaPrecoAlcool.bind(this);
    this.pegaPrecoGasolina = this.pegaPrecoGasolina.bind(this);
    this.calcular = this.calcular.bind(this);
  }
 
  calcular(){
    res = this.state.precoAlcool / this.state.precoGasolina
    if (res > 0.7)
      texto = 'Melhor Gasolina'
    else
      texto = 'Melhor Alcool'
    this.setState({
      resultado: texto
    });
  }

  pegaPrecoAlcool(preco){
    this.setState({precoAlcool: preco});
  }

  pegaPrecoGasolina(preco){
    this.setState({precoGasolina: preco});
  }
 
  render(){
    return(
      <View style={styles.container}>

      <Text style={styles.titulo}>Álcool ou Gasolina</Text>
 
      <Image
        source={{uri: 'https://play-lh.googleusercontent.com/uppnNukrvQ7ttY2yK0Jp1jretVddquUYEGjwVl8cNCGNL7J9P4OqSh-AqljkVJJjQVFL'}}
        style={{width: 150, height: 150, alignSelf: 'center', marginTop: 5}}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite o preço do alcool..."
        onChangeText={this.pegaPrecoAlcool}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite o preço da gasolina..."
        onChangeText={this.pegaPrecoGasolina}
      />

      <Button title="Calcular" onPress={this.calcular} />
 
      <Text style={styles.texto}> {this.state.resultado} </Text>
      </View>
    );
  }
}
 
export default App;