import React, { Component } from 'react';
import { View, Text} from 'react-native';


class App extends Component{
  render(){
    return(
      <View>
        <Text>Hello world!</Text>
        <Text>Meu Primeiro App</Text>
      </View>
    )
  }
}


export default App;