import React, { Component } from 'react';
import { View, Text, Button} from 'react-native';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      contador: 0
    };

    this.alterarContador = this.alterarContador.bind(this);
  }
  
  alterarContador(sinal){
    if (sinal == "+"){
      this.setState({
        contador: this.state.contador + 1
      });
    }
    else{
      if (this.state.contador > 0){
        this.setState({
          contador: this.state.contador - 1
        })
      }
    }
  }

  render(){
    return(
      <View style={{ marginTop: 20 }}>

        <View style={{alignItems: 'center'}}>
          <Text style={{color: 'red'}}>Contador de Pessoas - refeito, willian</Text>

          <Text style={{marginTop: 30, fontSize: 48, color: 'red'}}>{this.state.contador}</Text>
        </View>

        <View style={{marginTop: 20}}>
          <Button title="+" onPress={() => this.alterarContador('+')}/>
        </View>

        <View style={{marginTop: 20}}>
          <Button title="-" onPress={() => this.alterarContador('-')} />
        </View>

      </View>
    )
  }
}

export default App;