import React from 'react';
import { View, Text} from 'react-native';


function App(){
  return(
    <View>
      <Text>OLÁ MUNDO! APRESENTO MEU PRIMEIRO APP DA AULA DE PDM</Text>
    </View>
  )
}


export default App;